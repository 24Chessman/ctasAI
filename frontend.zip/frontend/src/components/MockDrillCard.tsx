import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Calendar, Users, MapPin, Target } from "lucide-react";

interface MockDrillCardProps {
  title: string;
  date: string;
  location: string;
  participants: number;
  maxParticipants: number;
  status: "upcoming" | "active" | "completed";
  type: "evacuation" | "shelter" | "communication" | "medical";
}

const MockDrillCard = ({ 
  title, 
  date, 
  location, 
  participants, 
  maxParticipants, 
  status, 
  type 
}: MockDrillCardProps) => {
  const getStatusColor = () => {
    switch (status) {
      case "upcoming":
        return "bg-primary text-primary-foreground";
      case "active":
        return "bg-warning text-warning-foreground";
      case "completed":
        return "bg-secondary text-secondary-foreground";
      default:
        return "bg-muted text-muted-foreground";
    }
  };

  const getTypeIcon = () => {
    switch (type) {
      case "evacuation":
        return "🚨";
      case "shelter":
        return "🏠";
      case "communication":
        return "📡";
      case "medical":
        return "🏥";
      default:
        return "🎯";
    }
  };

  return (
    <Card className="hover:shadow-lg transition-shadow">
      <CardHeader>
        <div className="flex items-start justify-between">
          <CardTitle className="text-lg flex items-center gap-2">
            <span className="text-xl">{getTypeIcon()}</span>
            {title}
          </CardTitle>
          <Badge className={getStatusColor()}>
            {status.toUpperCase()}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-2 gap-4 text-sm">
          <div className="flex items-center gap-2">
            <Calendar className="h-4 w-4 text-muted-foreground" />
            <span>{date}</span>
          </div>
          <div className="flex items-center gap-2">
            <MapPin className="h-4 w-4 text-muted-foreground" />
            <span>{location}</span>
          </div>
          <div className="flex items-center gap-2">
            <Users className="h-4 w-4 text-muted-foreground" />
            <span>{participants}/{maxParticipants} participants</span>
          </div>
          <div className="flex items-center gap-2">
            <Target className="h-4 w-4 text-muted-foreground" />
            <span className="capitalize">{type} drill</span>
          </div>
        </div>

        <div className="w-full bg-muted rounded-full h-2">
          <div 
            className="bg-primary h-2 rounded-full transition-all" 
            style={{ width: `${(participants / maxParticipants) * 100}%` }}
          />
        </div>

        <div className="flex gap-2">
          {status === "upcoming" && (
            <>
              <Button size="sm" variant="outline">View Details</Button>
              <Button size="sm">Join Drill</Button>
            </>
          )}
          {status === "active" && (
            <>
              <Button size="sm" variant="outline">Live View</Button>
              <Button size="sm" className="bg-warning hover:bg-warning/90">Participate</Button>
            </>
          )}
          {status === "completed" && (
            <>
              <Button size="sm" variant="outline">View Results</Button>
              <Button size="sm">Download Report</Button>
            </>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default MockDrillCard;