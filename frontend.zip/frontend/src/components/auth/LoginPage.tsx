import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { AlertCircle, Waves, Shield, Eye, EyeOff } from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert';

interface FormData {
  email: string;
  password: string;
}

interface FormErrors {
  [key: string]: string;
}

const LoginPage: React.FC = () => {
  const [formData, setFormData] = useState<FormData>({
    email: '',
    password: ''
  });

  const [errors, setErrors] = useState<FormErrors>({});
  const [isLoading, setIsLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  const validateForm = (): boolean => {
    const newErrors: FormErrors = {};

    // Email validation
    if (!formData.email) {
      newErrors.email = 'Email is required';
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = 'Email format is invalid';
    }

    // Password validation
    if (!formData.password) {
      newErrors.password = 'Password is required';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleInputChange = (field: keyof FormData, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    // Clear error when user starts typing
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }

    setIsLoading(true);
    setErrors({});

    try {
      // Mock API call - replace with actual Supabase integration
      console.log('Login data:', formData);

      // Simulate API delay
      await new Promise(resolve => setTimeout(resolve, 1500));

      // Mock user data - in real implementation, this would come from Supabase
      const mockUser = {
        id: 'user-123',
        email: formData.email,
        role: 'community' // This would be fetched from profiles table
      };

      console.log('Login successful:', mockUser);

      // Route based on user role
      const roleRedirects = {
        admin: '/admin-dashboard',
        authority: '/authority-dashboard',
        community: '/community-dashboard'
      };

      const redirectPath = roleRedirects[mockUser.role as keyof typeof roleRedirects] || '/community-dashboard';
      console.log(`Redirecting to: ${redirectPath}`);
      
      // In real implementation, navigate to the appropriate dashboard
      // Example: navigate(redirectPath);

    } catch (error) {
      console.error('Login error:', error);
      
      // Handle different types of errors
      if (error instanceof Error) {
        if (error.message.includes('Invalid login credentials')) {
          setErrors({ submit: 'Invalid email or password. Please try again.' });
        } else if (error.message.includes('Email not confirmed')) {
          setErrors({ submit: 'Please check your email and click the verification link.' });
        } else if (error.message.includes('Network')) {
          setErrors({ submit: 'Network error. Please check your connection and try again.' });
        } else {
          setErrors({ submit: 'Login failed. Please try again.' });
        }
      } else {
        setErrors({ submit: 'An unexpected error occurred. Please try again.' });
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleForgotPassword = () => {
    console.log('Navigate to forgot password');
    // In real implementation, navigate to forgot password page
  };

  const handleRegisterRedirect = () => {
    console.log('Navigate to registration');
    // In real implementation, navigate to registration page
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-coastal-light to-sand-DEFAULT flex items-center justify-center p-4">
      <Card className="w-full max-w-md shadow-xl border-0 bg-white/95 backdrop-blur">
        <CardHeader className="text-center space-y-4">
          <div className="flex items-center justify-center space-x-2">
            <Waves className="h-8 w-8 text-coastal" />
            <Shield className="h-8 w-8 text-environmental" />
          </div>
          <CardTitle className="text-3xl font-bold text-foreground">
            Welcome Back
          </CardTitle>
          <CardDescription className="text-lg text-muted-foreground">
            Sign in to your CTAS account
          </CardDescription>
        </CardHeader>

        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            {errors.submit && (
              <Alert variant="destructive">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>{errors.submit}</AlertDescription>
              </Alert>
            )}

            <div className="space-y-2">
              <Label htmlFor="email">Email Address</Label>
              <Input
                id="email"
                type="email"
                placeholder="Enter your email"
                value={formData.email}
                onChange={(e) => handleInputChange('email', e.target.value)}
                className={errors.email ? 'border-alert-error' : ''}
                autoComplete="email"
              />
              {errors.email && <p className="text-sm text-alert-error">{errors.email}</p>}
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label htmlFor="password">Password</Label>
                <button
                  type="button"
                  className="text-sm text-coastal hover:text-coastal-dark"
                  onClick={handleForgotPassword}
                >
                  Forgot password?
                </button>
              </div>
              <div className="relative">
                <Input
                  id="password"
                  type={showPassword ? 'text' : 'password'}
                  placeholder="Enter your password"
                  value={formData.password}
                  onChange={(e) => handleInputChange('password', e.target.value)}
                  className={errors.password ? 'border-alert-error pr-10' : 'pr-10'}
                  autoComplete="current-password"
                />
                <button
                  type="button"
                  className="absolute right-3 top-1/2 transform -translate-y-1/2 text-muted-foreground hover:text-foreground"
                  onClick={() => setShowPassword(!showPassword)}
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
              {errors.password && <p className="text-sm text-alert-error">{errors.password}</p>}
            </div>

            <Button 
              type="submit" 
              className="w-full bg-coastal hover:bg-coastal-dark text-white font-medium py-6"
              disabled={isLoading}
            >
              {isLoading ? 'Signing In...' : 'Sign In'}
            </Button>

            <div className="text-center space-y-4">
              <div className="relative">
                <div className="absolute inset-0 flex items-center">
                  <span className="w-full border-t" />
                </div>
                <div className="relative flex justify-center text-xs uppercase">
                  <span className="bg-background px-2 text-muted-foreground">New to CTAS?</span>
                </div>
              </div>
              
              <Button
                type="button"
                variant="outline"
                className="w-full border-coastal text-coastal hover:bg-coastal hover:text-white"
                onClick={handleRegisterRedirect}
              >
                Create Account
              </Button>
            </div>

            <div className="text-center">
              <p className="text-xs text-muted-foreground">
                By signing in, you agree to our{' '}
                <button className="text-coastal hover:text-coastal-dark underline">
                  Terms of Service
                </button>{' '}
                and{' '}
                <button className="text-coastal hover:text-coastal-dark underline">
                  Privacy Policy
                </button>
              </p>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
};

export default LoginPage;