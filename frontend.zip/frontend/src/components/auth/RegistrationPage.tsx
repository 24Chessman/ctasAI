import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { AlertCircle, Upload, Waves, Shield } from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert';

interface FormData {
  email: string;
  password: string;
  confirmPassword: string;
  fullName: string;
  gender: string;
  age: string;
  address: string;
  city: string;
  state: string;
  zipCode: string;
  country: string;
  locationUrl: string;
  plusCode: string;
  role: string;
}

interface FormErrors {
  [key: string]: string;
}

const RegistrationPage: React.FC = () => {
  const [formData, setFormData] = useState<FormData>({
    email: '',
    password: '',
    confirmPassword: '',
    fullName: '',
    gender: '',
    age: '',
    address: '',
    city: '',
    state: '',
    zipCode: '',
    country: 'India',
    locationUrl: '',
    plusCode: '',
    role: ''
  });

  const [errors, setErrors] = useState<FormErrors>({});
  const [idFile, setIdFile] = useState<File | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [success, setSuccess] = useState('');

  const validateForm = (): boolean => {
    const newErrors: FormErrors = {};

    // Email validation
    if (!formData.email) {
      newErrors.email = 'Email is required';
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = 'Email format is invalid';
    }

    // Password validation
    if (!formData.password) {
      newErrors.password = 'Password is required';
    } else if (formData.password.length < 6) {
      newErrors.password = 'Password must be at least 6 characters';
    }

    if (formData.password !== formData.confirmPassword) {
      newErrors.confirmPassword = 'Passwords do not match';
    }

    // Required fields
    const requiredFields = ['fullName', 'gender', 'age', 'address', 'city', 'state', 'zipCode', 'role'];
    requiredFields.forEach(field => {
      if (!formData[field as keyof FormData]) {
       newErrors[field] = `${field.charAt(0).toUpperCase() + field.slice(1)} is required`;
      }
    });

    // Location validation (either locationUrl or plusCode required)
    if (!formData.locationUrl && !formData.plusCode) {
      newErrors.location = 'Either location URL or Plus Code is required';
    }

    // Authority role file validation
    if (formData.role === 'authority' && !idFile) {
      newErrors.idFile = 'ID card upload is required for authority users';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleInputChange = (field: keyof FormData, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    // Clear error when user starts typing
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      // Validate file type and size
      const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png'];
      if (!allowedTypes.includes(file.type)) {
        setErrors(prev => ({ ...prev, idFile: 'Only JPEG, JPG, and PNG files are allowed' }));
        return;
      }
      if (file.size > 5 * 1024 * 1024) { // 5MB limit
        setErrors(prev => ({ ...prev, idFile: 'File size must be less than 5MB' }));
        return;
      }
      setIdFile(file);
      setErrors(prev => ({ ...prev, idFile: '' }));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }

    setIsLoading(true);
    setErrors({});

    try {
      // Mock API call - replace with actual Supabase integration
      console.log('Registration data:', formData);
      if (idFile) {
        console.log('ID file:', idFile);
      }

      // Simulate API delay
      await new Promise(resolve => setTimeout(resolve, 2000));

      setSuccess('Registration successful! Please check your email for verification.');
      
      // In real implementation, redirect to login page
      setTimeout(() => {
        console.log('Redirecting to login page...');
      }, 2000);

    } catch (error) {
      setErrors({ submit: 'Registration failed. Please try again.' });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-coastal-light to-sand-DEFAULT flex items-center justify-center p-4">
      <Card className="w-full max-w-2xl shadow-xl border-0 bg-white/95 backdrop-blur">
        <CardHeader className="text-center space-y-4">
          <div className="flex items-center justify-center space-x-2">
            <Waves className="h-8 w-8 text-coastal" />
            <Shield className="h-8 w-8 text-environmental" />
          </div>
          <CardTitle className="text-3xl font-bold text-foreground">
            Join CTAS
          </CardTitle>
          <CardDescription className="text-lg text-muted-foreground">
            Coastal Threat Alert System Registration
          </CardDescription>
        </CardHeader>

        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            {errors.submit && (
              <Alert variant="destructive">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>{errors.submit}</AlertDescription>
              </Alert>
            )}

            {success && (
              <Alert className="border-environmental bg-environmental-light/10">
                <Shield className="h-4 w-4 text-environmental" />
                <AlertDescription className="text-environmental-dark">{success}</AlertDescription>
              </Alert>
            )}

            {/* Email and Password Section */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="email">Email Address *</Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => handleInputChange('email', e.target.value)}
                  className={errors.email ? 'border-alert-error' : ''}
                />
                {errors.email && <p className="text-sm text-alert-error">{errors.email}</p>}
              </div>

              <div className="space-y-2">
                <Label htmlFor="fullName">Full Name *</Label>
                <Input
                  id="fullName"
                  value={formData.fullName}
                  onChange={(e) => handleInputChange('fullName', e.target.value)}
                  className={errors.fullName ? 'border-alert-error' : ''}
                />
                {errors.fullName && <p className="text-sm text-alert-error">{errors.fullName}</p>}
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="password">Password *</Label>
                <Input
                  id="password"
                  type="password"
                  value={formData.password}
                  onChange={(e) => handleInputChange('password', e.target.value)}
                  className={errors.password ? 'border-alert-error' : ''}
                />
                {errors.password && <p className="text-sm text-alert-error">{errors.password}</p>}
              </div>

              <div className="space-y-2">
                <Label htmlFor="confirmPassword">Confirm Password *</Label>
                <Input
                  id="confirmPassword"
                  type="password"
                  value={formData.confirmPassword}
                  onChange={(e) => handleInputChange('confirmPassword', e.target.value)}
                  className={errors.confirmPassword ? 'border-alert-error' : ''}
                />
                {errors.confirmPassword && <p className="text-sm text-alert-error">{errors.confirmPassword}</p>}
              </div>
            </div>

            {/* Personal Information Section */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="gender">Gender *</Label>
                <Select value={formData.gender} onValueChange={(value) => handleInputChange('gender', value)}>
                  <SelectTrigger className={errors.gender ? 'border-alert-error' : ''}>
                    <SelectValue placeholder="Select gender" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="male">Male</SelectItem>
                    <SelectItem value="female">Female</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
                {errors.gender && <p className="text-sm text-alert-error">{errors.gender}</p>}
              </div>

              <div className="space-y-2">
                <Label htmlFor="age">Age *</Label>
                <Input
                  id="age"
                  type="number"
                  value={formData.age}
                  onChange={(e) => handleInputChange('age', e.target.value)}
                  className={errors.age ? 'border-alert-error' : ''}
                />
                {errors.age && <p className="text-sm text-alert-error">{errors.age}</p>}
              </div>

              <div className="space-y-2">
                <Label htmlFor="country">Country</Label>
                <Input
                  id="country"
                  value={formData.country}
                  onChange={(e) => handleInputChange('country', e.target.value)}
                />
              </div>
            </div>

            {/* Address Section */}
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="address">Full Address *</Label>
                <Input
                  id="address"
                  value={formData.address}
                  onChange={(e) => handleInputChange('address', e.target.value)}
                  className={errors.address ? 'border-alert-error' : ''}
                />
                {errors.address && <p className="text-sm text-alert-error">{errors.address}</p>}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="city">City *</Label>
                  <Input
                    id="city"
                    value={formData.city}
                    onChange={(e) => handleInputChange('city', e.target.value)}
                    className={errors.city ? 'border-alert-error' : ''}
                  />
                  {errors.city && <p className="text-sm text-alert-error">{errors.city}</p>}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="state">State *</Label>
                  <Input
                    id="state"
                    value={formData.state}
                    onChange={(e) => handleInputChange('state', e.target.value)}
                    className={errors.state ? 'border-alert-error' : ''}
                  />
                  {errors.state && <p className="text-sm text-alert-error">{errors.state}</p>}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="zipCode">Zip Code *</Label>
                  <Input
                    id="zipCode"
                    value={formData.zipCode}
                    onChange={(e) => handleInputChange('zipCode', e.target.value)}
                    className={errors.zipCode ? 'border-alert-error' : ''}
                  />
                  {errors.zipCode && <p className="text-sm text-alert-error">{errors.zipCode}</p>}
                </div>
              </div>
            </div>

            {/* Location Section */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="locationUrl">Location URL</Label>
                <Input
                  id="locationUrl"
                  placeholder="Google Maps link, What3Words, etc."
                  value={formData.locationUrl}
                  onChange={(e) => handleInputChange('locationUrl', e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="plusCode">Plus Code</Label>
                <Input
                  id="plusCode"
                  placeholder="e.g., 7JWV+8X Chennai"
                  value={formData.plusCode}
                  onChange={(e) => handleInputChange('plusCode', e.target.value)}
                />
              </div>
            </div>
            {errors.location && <p className="text-sm text-alert-error">{errors.location}</p>}

            {/* Role Selection */}
            <div className="space-y-4">
              <Label>Role *</Label>
              <RadioGroup 
                value={formData.role} 
                onValueChange={(value) => handleInputChange('role', value)}
                className="grid grid-cols-1 md:grid-cols-2 gap-4"
              >
                <div className="flex items-center space-x-2 p-4 border rounded-lg hover:bg-muted/50">
                  <RadioGroupItem value="community" id="community" />
                  <Label htmlFor="community" className="flex-1 cursor-pointer">
                    <div className="font-medium">Community Member</div>
                    <div className="text-sm text-muted-foreground">Report threats and receive alerts</div>
                  </Label>
                </div>

                <div className="flex items-center space-x-2 p-4 border rounded-lg hover:bg-muted/50">
                  <RadioGroupItem value="authority" id="authority" />
                  <Label htmlFor="authority" className="flex-1 cursor-pointer">
                    <div className="font-medium">Authority</div>
                    <div className="text-sm text-muted-foreground">Manage threats and coordinate response</div>
                  </Label>
                </div>
              </RadioGroup>
              {errors.role && <p className="text-sm text-alert-error">{errors.role}</p>}
            </div>

            {/* Authority ID Upload */}
            {formData.role === 'authority' && (
              <div className="space-y-2">
                <Label htmlFor="idFile">ID Card Upload *</Label>
                <div className="border-2 border-dashed border-input rounded-lg p-4 text-center">
                  <Upload className="h-8 w-8 mx-auto mb-2 text-muted-foreground" />
                  <Input
                    id="idFile"
                    type="file"
                    accept="image/jpeg,image/jpg,image/png"
                    onChange={handleFileChange}
                    className="hidden"
                  />
                  <Label htmlFor="idFile" className="cursor-pointer">
                    <span className="text-coastal hover:text-coastal-dark">
                      {idFile ? idFile.name : 'Click to upload ID card'}
                    </span>
                  </Label>
                  <p className="text-xs text-muted-foreground mt-2">
                    JPEG, JPG, or PNG. Max 5MB.
                  </p>
                </div>
                {errors.idFile && <p className="text-sm text-alert-error">{errors.idFile}</p>}
              </div>
            )}

            <Button 
              type="submit" 
              className="w-full bg-coastal hover:bg-coastal-dark text-white font-medium py-6"
              disabled={isLoading}
            >
              {isLoading ? 'Creating Account...' : 'Create Account'}
            </Button>

            <div className="text-center">
              <p className="text-muted-foreground">
                Already have an account?{' '}
                <button
                  type="button"
                  className="text-coastal hover:text-coastal-dark font-medium"
                  onClick={() => console.log('Navigate to login')}
                >
                  Sign in here
                </button>
              </p>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
};

export default RegistrationPage;