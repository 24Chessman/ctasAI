from fastapi import APIRouter, HTTPException
from app.services.prediction_service import prediction_service
import pandas as pd

router = APIRouter()

@router.post("/predict")
async def predict_cyclone(data: dict):
    """
    Predict cyclone probability from sensor data
    
    Expected data format:
    {
        "wind_speed": 15.2,
        "pressure": 1005.3,
        "wave_height": 3.2,
        "water_level": 1.5,
        "hour": 14,
        "day_of_year": 243,
        "month": 8,
        "day_of_week": 2,
        "is_weekend": 0,
        "pressure_change_6h": -2.1,
        "wind_speed_change_6h": 5.3,
        "pressure_trend": 1007.1,
        "wind_speed_trend": 12.8,
        "pressure_std_12h": 1.2,
        "wave_height_change": 0.8,
        "pressure_drop_rate": -0.35
    }
    """
    try:
        result = prediction_service.predict_cyclone(data)
        
        if "error" in result:
            raise HTTPException(status_code=400, detail=result["error"])
        
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/predict/batch")
async def predict_cyclone_batch(data: list):
    """
    Predict cyclone probability for multiple sensor readings
    """
    try:
        results = prediction_service.predict_batch(data)
        
        if isinstance(results, dict) and "error" in results:
            raise HTTPException(status_code=400, detail=results["error"])
        
        return {"predictions": results}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/health")
async def health_check():
    """
    Health check endpoint to verify the prediction service is working
    """
    return {"status": "healthy", "message": "Cyclone prediction service is running"}