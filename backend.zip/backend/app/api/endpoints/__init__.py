from .predict import router as predict_router
from .alerts import router as alerts_router
from .data import router as data_router

__all__ = ["predict_router", "alerts_router", "data_router"]