# app/api/endpoints/alerts.py
from fastapi import APIRouter

router = APIRouter()

@router.get("/")
async def get_alerts():
    return {"message": "Alerts endpoint is working"}

# You can add more alert-related endpoints here later