# backend/app/automation/scheduler.py
import schedule
import time
import logging
import os
from datetime import datetime
from app.ml_models.cyclone_predictor import cyclone_predictor
from app.services.data_fetcher import fetch_weather_data
from app.services.alert_system import check_and_send_alerts
from app.services.storm_surge_predictor import storm_surge_predictor

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def prediction_job():
    """
    Job that runs every 5 minutes to fetch data and make predictions
    """
    try:
        logger.info(f"Running prediction job at {datetime.now()}")
        
        # Fetch current weather data
        weather_data = fetch_weather_data()
        logger.info(f"Fetched weather data: {weather_data}")
        
        # 1. Cyclone Prediction
        cyclone_prediction = cyclone_predictor.predict(weather_data)
        logger.info(f"Cyclone prediction: {cyclone_prediction}")
        
        # 2. Storm Surge Prediction
        surge_prediction = storm_surge_predictor.predict_storm_surge(weather_data)
        logger.info(f"Storm surge prediction: {surge_prediction}")
        
        # Combine predictions
        comprehensive_prediction = {
            "timestamp": datetime.now().isoformat(),
            "cyclone": cyclone_prediction,
            "storm_surge": surge_prediction,
            "overall_threat_level": assess_overall_threat(cyclone_prediction, surge_prediction)
        }
        
        # Check if we need to send alerts
        check_and_send_alerts(comprehensive_prediction, weather_data)
        
    except Exception as e:
        logger.error(f"Error in prediction job: {e}")

def assess_overall_threat(cyclone_data, surge_data):
    """
    Combine cyclone and storm surge threats into an overall threat level
    """
    # Extract threat levels
    cyclone_threat = "high" if cyclone_data.get('classification') == 'CYCLONE' and cyclone_data.get('probability', 0) > 0.7 else "low"
    surge_threat = surge_data.get('threat_level', 'low')
    
    # Threat hierarchy
    threat_levels = {"low": 0, "moderate": 1, "high": 2, "extreme": 3}
    
    # Get the maximum threat level
    max_threat = max(
        threat_levels.get(cyclone_threat, 0),
        threat_levels.get(surge_threat, 0)
    )
    
    # Convert back to text
    for level, value in threat_levels.items():
        if value == max_threat:
            return level
    
    return "low"

def start_scheduler():
    """
    Start the scheduled job to run every 5 minutes
    """
    try:
        # Schedule the job to run every 5 minutes
        schedule.every(1).minutes.do(prediction_job)
        
        # Run immediately on startup
        prediction_job()
        
        logger.info("Coastal threat scheduler started. Running predictions every 1 minutes.")
        
        # Keep the scheduler running
        while True:
            schedule.run_pending()
            time.sleep(1)
            
    except Exception as e:
        logger.error(f"Error starting scheduler: {e}")

if __name__ == "__main__":
    start_scheduler()