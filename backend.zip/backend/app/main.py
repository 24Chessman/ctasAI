# backend/app/main.py
import os
from pathlib import Path
from dotenv import load_dotenv
from fastapi import FastAPI
from contextlib import asynccontextmanager
import threading
from app.api.endpoints import predict, data, alerts
from app.automation.scheduler import start_scheduler

# Load environment variables from the backend/.env file
env_path = Path(__file__).resolve().parent.parent / '.env'
load_dotenv(env_path)

# Check if environment variables are loaded
print("Environment variables loaded:")
print("WEATHERAPI_API_KEY:", "SET" if os.getenv("WEATHERAPI_API_KEY") else "MISSING")
print("OPENWEATHERMAP_API_KEY:", "SET" if os.getenv("OPENWEATHERMAP_API_KEY") else "MISSING")

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Start the scheduler in a separate thread when the app starts
    scheduler_thread = threading.Thread(target=start_scheduler, daemon=True)
    scheduler_thread.start()
    print("Automated prediction scheduler started")
    
    yield
    
    # Clean up when the app stops
    print("Shutting down scheduler")

app = FastAPI(
    title="Cyclone Detection API",
    description="API for detecting cyclones from buoy sensor data",
    version="1.0.0",
    lifespan=lifespan
)

# Include routers
app.include_router(predict.router, prefix="/api/v1", tags=["prediction"])
app.include_router(data.router, prefix="/api/v1", tags=["data"])
app.include_router(alerts.router, prefix="/api/v1", tags=["alerts"])

@app.get("/")
async def root():
    return {"message": "Cyclone Detection API"}

@app.get("/health")
async def health_check():
    return {"status": "healthy", "message": "System is running"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)