from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    PROJECT_NAME: str = "Nereid API"
    # Database settings (if using Supabase)
    SUPABASE_URL: str = "your-supabase-url-here"
    SUPABASE_KEY: str = "your-supabase-key-here"
    # API settings
    API_V1_STR: str = "/api/v1"
    
    class Config:
        env_file = ".env"

settings = Settings()