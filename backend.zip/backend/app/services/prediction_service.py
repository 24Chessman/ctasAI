from app.ml_models.cyclone_predictor import cyclone_predictor
import pandas as pd

class PredictionService:
    def __init__(self):
        self.predictor = cyclone_predictor
    
    def predict_cyclone(self, data):
        """
        Predict cyclone probability from sensor data
        
        Args:
            data: Dictionary or DataFrame containing sensor readings
        
        Returns:
            Prediction result with probability and classification
        """
        # Convert to DataFrame if it's a dictionary
        if isinstance(data, dict):
            data = pd.DataFrame([data])
        
        return self.predictor.predict(data)
    
    def predict_batch(self, data_list):
        """
        Predict cyclone probability for a batch of sensor data
        
        Args:
            data_list: List of dictionaries or DataFrame containing multiple sensor readings
        
        Returns:
            List of prediction results
        """
        # Convert to DataFrame if it's a list of dictionaries
        if isinstance(data_list, list) and isinstance(data_list[0], dict):
            data_list = pd.DataFrame(data_list)
        
        return self.predictor.predict_batch(data_list)

# Create a singleton instance
prediction_service = PredictionService()